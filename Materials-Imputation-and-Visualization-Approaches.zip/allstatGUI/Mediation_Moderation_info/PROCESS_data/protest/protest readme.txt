Garcia, D. M., Schmitt, M. T., Branscombe, N. R., & Ellemers, N. (2010).  Women's reactions to ingroup members who protest discriminatory treatment: The importance of beliefs about inequality and response appropriateness.  European Journal of Social Psychology, 40, 733-745.


PROTEST.TXT

Variable          Rec   Start     End  Format 
sexism              1       1       8  F8.2 
liking              1       9      16  F8.2 
respappr            1      17      24  F8.2 
protest             1      25      32  F8.2


protest:  0 = no protest, 1 = protest
