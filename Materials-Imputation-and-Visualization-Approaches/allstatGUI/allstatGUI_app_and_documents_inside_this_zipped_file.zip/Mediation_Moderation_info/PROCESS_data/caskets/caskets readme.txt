Hayes, A. F., & Reineke, J. B. (2007). The effects of government censorship of war-related news coverage on interest in the censored coverage: A test of competing theories. Mass Communication and Society, 10, 423-438


CASKETS.TXT
 
Variable          Rec   Start     End  Format 
policy              1       1       8  F8.2 
interest            1       9      16  F8.2 
age                 1      17      24  F8.2 
educ                1      25      32  F8.2 
male                1      33      40  F8.2 
conserv             1      41      48  F8.2 
kerry               1      49      56  F8.2 

policy: 0 = not told about policy, 1 = told about policy
kerry:  0 = not Kerry supporter, 1 = kerry supporter
