Pollack, J., VanEpps, E. M., & Hayes, A. F. (2012). The moderating role of social ties on entrepreneurs' depressed affect and withdrawal intentions in response to economic stress. Journal of Organizational Behavior, 33, 789-810.
 

ESTRESS.TXT
 
Variable          Rec   Start     End  Format 
tenure              1       1       8  F8.2 
estress             1       9      16  F8.2 
affect              1      17      24  F8.2 
withdraw            1      25      32  F8.2 
sex                 1      33      40  F8.0 
age                 1      41      48  F8.0 
ese                 1      49      56  F8.2

Sex:  0 = female, 1 = male
