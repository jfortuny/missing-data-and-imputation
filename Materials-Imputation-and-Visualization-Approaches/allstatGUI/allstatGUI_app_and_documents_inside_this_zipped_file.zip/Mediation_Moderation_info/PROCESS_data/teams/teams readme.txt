Cole, M. S., Walter, F., & Bruch, H. (2008). Affective mechanisms linking dysfunctional behavior to performance in work teams: A moderated mediation study. Journal of Applied Psychology, 93, 945-958.  


TEAMS.TXT
 
Variable          Rec   Start     End  Format 
dysfunc             1       1       8  F8.2 
negtone             1       9      16  F8.2 
negexp              1      17      24  F8.2 
perform             1      25      32  F8.2 

