Tal-Or, N., Cohen, J., Tsafati, Y., & Gunther, A. C. (2010). Testing causal direction in the influence of presumed media influence. Communication Research, 37, 801-824. 


PMI.TXT
 
Variable          Rec   Start     End  Format 
cond                1       1       8  F8.2 
pmi                 1       9      16  F8.2 
import              1      17      24  F8.2 
reaction            1      25      32  F8.2 
gender              1      33      40  F8.2 
age                 1      41      48  F8.2 


gender:  0 = female, 1 = male