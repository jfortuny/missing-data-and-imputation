
GLBWARM.TXT
 
Variable          Rec   Start     End  Format 
govact              1       1       8  F8.2 
posemot             1       9      16  F8.2 
negemot             1      17      24  F8.2 
ideology            1      25      32  F8.0 
age                 1      33      40  F8.0 
sex                 1      41      48  F8.0 
partyid             1      49      56  F8.0

Sex:  0 = female, 1 = male
Partyid: 1 = democrat, 2 = independent, 3 = republican